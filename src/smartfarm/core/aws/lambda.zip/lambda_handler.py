# lambda_handler.py
import json
from lambda_member import member_get_cost_with_lambda

def lambda_handler(event, context):
    members = event["members"]
    sim_ctx = event["sim_context"]

    costs = []
    for m in members:
        cost = member_get_cost_with_lambda(m, sim_ctx)
        costs.append(cost)

    return {
        "statusCode": 200,
        "body": json.dumps({"costs": costs})
    }
